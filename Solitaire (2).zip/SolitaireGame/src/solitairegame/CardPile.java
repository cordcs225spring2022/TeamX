/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solitairegame;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Queue;
import javax.swing.JPanel;
import static solitairegame.Card.height;
import static solitairegame.Card.width;


/**
 *
 * @author bgebreey
 */
/*
*The following class defines the card pile
*/
public class CardPile extends Card {
    public ArrayList<Card> pile;
    public int x;
    public int y;
    ArrayList<Card> faceUp = new ArrayList<Card>();
    ArrayList<Card> faceDown = new ArrayList<Card>();
    public CardPile(int x1, int y1 ){
        pile = new ArrayList<Card>();
        x1=x;
        y1=y; 
    }
    /*
    *This method adds card to face up pile.
    */
    public void addCardToFaceUp(Card card){
        faceUp.add(card);
    }
    /*
    *This method adds card to face down pile.
    */
    public void addCardToFaceDown(Card card){
        faceDown.add(card);
    }
    /*
    *This method counts number of face up cards.
    */
    public int countFaceUp(){
        return faceUp.size();
    }
    /*
    *This method counts number of face down cards.
    */
    public int countFaceDown(){
        return faceDown.size();
    }
    /*
    *This method adds a card to the pile.
    */
    public void addCard(Card card){
        pile.add(card);
    }
    /*
    *This method allows for the cards that can be taken at each stage of the game to be taken. 
    */
    public boolean canTakeCard(){
        return false;
    }    
    /*
    *This method removes a card from the pile.
    */
    public void removeCard(Card card){
        pile.remove(card);
    }
    /*
    *this method sorts the cards. 
    */
     public void sortCards(ArrayList<Card> faceUp,ArrayList<Card> faceDown){
        pile.sort((Comparator<? super Card>) faceUp);
        pile.sort((Comparator<? super Card>) faceDown);
    }
     /*
     *this method paints the card pile. 
     */
    public void paint(Graphics g){
        super.paint(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setStroke(new BasicStroke(5));
        g2.setColor(Color.white);
        g2.drawRect(30, 40, width, height);
        
    }
 }
