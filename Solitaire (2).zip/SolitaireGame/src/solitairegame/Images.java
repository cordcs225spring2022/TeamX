/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solitairegame;

import java.awt.Image;
import java.util.HashMap;
import java.util.Map;
import javafx.scene.image.ImageView;
import javax.imageio.ImageIO;


/**
 *
 * @author bgebreey
 */
public class Images {
    private static Map<String,ImageView> cards = new HashMap<String,ImageView>();
    private static String locationOfImages = "Images/";
    private static String imageType = ".png";
    public static ImageView getImage(String slot){
        ImageView picture = cards.get(slot);
        if(picture == null){
            picture = ImageIO.read(getResource(locationOfImages+slot+imageType));
            //picture  = new ImageView(Images.class.getClassLoader().getResourceAsStream(locationOfImages+slot+imageType));
            cards.put(slot,picture);
        }
        return picture;
    }
    public static ImageView getImageBack() {
        return getImage("3OfHearts");
    }
}
