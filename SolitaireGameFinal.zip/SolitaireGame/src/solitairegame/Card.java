/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solitairegame;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.util.Collections;
import java.util.Queue;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import static solitairegame.SuitOfCards.Clubs;
import static solitairegame.SuitOfCards.Diamonds;
import static solitairegame.SuitOfCards.Hearts;
import static solitairegame.SuitOfCards.Spades;

/**
 *
 * @author bgebreey
 */
/*
*This class defines the properties of the card
*/
public class Card extends JPanel{
    /*
    *these variables define the properties of the card
    */
    protected String faceOfCard;
    public boolean cardFaceUp;
    protected String suit;
    protected  SuitOfCards suitOfCard;
    protected Color color;
    protected int valueOfCard;
    protected int rankOfCard;
    protected Image cardImage; 
    
    public final static String diamond = "Diamond";
    public final static String club = "Club";
    public final static String heart = "Heart";
    public final static String spade = "Spade";
    
    public final static String red="Red";
    public final static String black="Black";
    
    public final static int height=50;
    public final static int width=60; 
    /*
    *The following methods are the getters and setter for theproperties of the cards 
    */
    /*
    *The following metthod gets the face of the card.
    */
    public String getFaceOfCard(){
        return faceOfCard;
    }
    /*
    *The following method sets the face of the card.
    */
    public void setFaceOfCard(String aNameOfCard){
        faceOfCard=aNameOfCard;
    }
    /*
    *The following method gets the suit of the card.
    */
    public SuitOfCards getSuitOfCard(){
        return suitOfCard;
    }
    /*
    *The following method get the face of the card.
    */
    public void setSuitOfCard(SuitOfCards aSuitOfCard){
        suitOfCard=aSuitOfCard;
    }
     /*
    *The following method returns the suit of the card.
    */
    public String suitOfCard(){
        return suit;
    }
     /*
    *The following method get the value of the card.
    */
    public int getValueOfCard(){
        return valueOfCard;
    }
     /*
    *The following method sets the value of the card.
    */
    public void setValueOfCard(int aValueOfCard){
        valueOfCard=aValueOfCard;
    }
     /*
    *The following method get the image of the card.
    */
    public Image getCardImage(){
        return cardImage;
    } 
    /*
    *The following method sets the image of the card.
    */
    public void setCardImage(Image aCardImage){
        cardImage=aCardImage;
    }
     /*
    *The following method sets the cards that are face up.
    */
    public void setCardFaceUp(boolean aCardFaceUp){
        cardFaceUp=!aCardFaceUp;
    }
     /*
    *The following method returns wether the card is face up or not.
    */
    public boolean isCardFaceUp(){
        return cardFaceUp;
    }
     /*
    *The following method get the rank of the card.
    */
    public int getRankOfCard(){
        return rankOfCard;
    }
     /*
    *The following method sets the rank of the card.
    */
    public void setRankOfCard(int aRankOfCard){
        rankOfCard=aRankOfCard;
    }
     /*
    *The following method get the string verion of color of the card.
    */
    public String colorOfCard(){
        if(suitOfCard()==diamond){
            return red;
        } 
        else if(getSuitOfCard().equals(club)){
                    return club;
        }
        else if(getSuitOfCard().equals(heart)){
                return heart;
        }
        else if(getSuitOfCard().equals(spade)){
                return black;
        }    
        return null;
     
    }
     /*
    *The following method sets the color of the type of cards.
    */
    public Color color(){
        if(cardFaceUp==true){
            if(getSuitOfCard().equals(diamond)){
                return Color.RED;
            }
            else if(getSuitOfCard().equals(heart)){
                    return Color.RED;
            }
            else if(getSuitOfCard().equals(club)){
                return Color.BLACK;
            }
            else if(getSuitOfCard().equals(spade)){
                return Color.BLACK;
            }
        }
        return null;
    }
    
    public Card(String aFaceOfCard,SuitOfCards aSuit,int aValueOfCard, Image aCardImage, int aRankOfCard, boolean aCardFaceUp){
        setFaceOfCard(aFaceOfCard);
        setSuitOfCard(aSuit);
        setValueOfCard(aValueOfCard);
        setCardImage(aCardImage);
        setRankOfCard(aRankOfCard);
        setCardFaceUp(aCardFaceUp);
        
        if(aSuit==Diamonds){
            suit=diamond;
            color=color.red;
        }
        else if(aSuit==Clubs){
            suit=club;
            color=color.black;
        }
        else if(aSuit==Hearts){
            suit=club;
            color=color.black;
        }
        else if(aSuit==Spades){
            suit=club;
            color=color.black;
        }
        cardFaceUp=false;
    }

    

}