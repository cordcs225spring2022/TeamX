/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solitairegame;

import java.awt.BorderLayout;
import java.io.File;
import java.io.IOException;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
//import javafx.application.Application;


/**
 *
 * @author bgebreey
 */
public class SolitaireGame{

    /**
     * @param args the command line arguments
     */
   
    private static int width = 600;
    private static int length = 500;
    public static void main(String[] args) throws IOException {
        Card aceOfSpades = new Card("Spades",spades,14,ImageIO.read(new File("Ace_Of_Spades.png")),0,true);
        JFrame window = new JFrame("Display Solitaire Game");
        window.setSize(700,800);
        window.setDefaultCloseOperation(JFrame. EXIT_ON_CLOSE);
        window.setVisible(true);
        JPanel content = new JPanel(new BorderLayout());
        JLabel card = new JLabel(new ImageIcon(aceOfSpades.getCardImage()));
        card.setSize(50,100);
        content.add(card);
        window.add(content);
        
       
    }
}
