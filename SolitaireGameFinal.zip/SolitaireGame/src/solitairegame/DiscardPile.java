/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solitairegame;

/**
 *
 * @author bgebreey
 */
/*
*This class defines the discard class
*/
public class DiscardPile extends CardPile{
    
    public DiscardPile(int x, int y){
        super(x,y); 
    }
    /*
    *this method discards cards. 
    */
    public Card discardCard(){
        if(cardFaceUp==true){
            int i = faceDown.size()-1;
            return faceDown.remove(i);
        }
        else if(cardFaceUp==false){
            int i = faceUp.size()-1;
            return faceUp.remove(i);         
        }
    return null;
    }
    
    
}
