/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solitairegame;


import java.awt.Color;
import java.awt.Graphics;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.util.Iterator;
import java.util.Stack;
/**
 *
 * @author anaro
 */
/*
*This class defines the suit pile class
*/
public class SuitPile extends CardPile 
{
  public SuitPile (int x, int y) 
  { 
    super(x, y); 
  }

  public boolean canTake (Card card) 
  {
    if (isEmpty())
      return card.isAce();

    Card topCard = top();
    return (card.getSuitOfCard() == topCard.getSuitOfCard()) &&
           (card.getRankOfCard() == 1 + topCard.getRankOfCard());
  }

  public void select (int tx, int ty)   
  {
    if (isEmpty())
      return;

    Card topCard = top();
  } 
