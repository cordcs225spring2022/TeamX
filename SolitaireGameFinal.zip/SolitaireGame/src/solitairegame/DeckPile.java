/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solitairegame;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Random;
import java.util.Queue;
import static solitairegame.Card.height;
import static solitairegame.Card.width;
/**
 *
 * @author bgebreey
 */
/*
*The following class defines the deck pile
*/
public class DeckPile extends CardPile{
   /*
    *the deck variable is an arraylist of all the cards
    *
    */
    public ArrayList<Card> deck;
    public boolean deckIsEmpty;
    public int numberOfCards=52;
    public DeckPile(int x, int y){
        super(x,y);
        deck = new ArrayList<Card>(numberOfCards);
        for(int i =0;i<numberOfCards;i++){
            deck.add(new Card(faceOfCard,suitOfCard,valueOfCard, cardImage,rankOfCard, cardFaceUp));
        }
    }
    /*
    *This  method gets an empty deck pile. 
    */
    public boolean getDeckIsEmpty(){
        if(deck.size()==0){
            return true;
        }
        else{
            return false;
        }
        
    }
    /*
    *This method shuffles the cards in the deck pile.
    */
    public void shuffleCards(){
        Random rand = new Random();
        for(int move=0; move<numberOfCards-1;numberOfCards++){
            int randomGenerator = rand.nextInt(numberOfCards-1);
            Card holder = deck.get(move);
            deck.set(randomGenerator,holder);
        }
    }
    /*
    *This method paints the deck pile. 
    */
    public void paint(Graphics g){
        super.paint(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setStroke(new BasicStroke(5));
        g2.setColor(Color.white);
        g2.drawRect(100, 110, width, height);
        
    }
}
